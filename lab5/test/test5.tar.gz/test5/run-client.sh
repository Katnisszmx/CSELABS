#!/bin/bash
./yfs_client $1 $2 $3 > yfs_client1.log 2>&1 &
